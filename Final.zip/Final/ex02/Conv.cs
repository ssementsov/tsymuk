﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ex02
{
    public class Conv
    {
        public string ConvertToStr(int value)
        {
            string aN = value.ToString();
            string newSt = string.Empty;
            for (int i = 0; i < aN.Length; i++)
            {
                if (aN[i] == 1)
                {
                   string.Join(newSt, aN[i]);
                }
                if (aN[i] == 2)
                {
                    string.Join(newSt, aN[i]);
                }
                if (aN[i] == 3)
                {
                    string.Join(newSt, aN[i]);
                }
                if (aN[i] == 4)
                {
                    string.Join(newSt, aN[i]);
                }
            }
            return newSt;
        }
    }
}
