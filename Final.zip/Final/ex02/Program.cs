﻿using ex02;
Conv con = new Conv();

string nstr = con.ConvertToStr(1234);
Console.WriteLine(nstr);
